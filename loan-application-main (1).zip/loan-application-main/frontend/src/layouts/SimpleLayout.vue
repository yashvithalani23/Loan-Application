<script setup lang="ts"></script>

<template>
  <div class="page-layout">
    <RouterView />
  </div>
</template>

<style lang="scss" scoped>
.page-layout {
  display: flex;
  flex-direction: column;
}
</style>
