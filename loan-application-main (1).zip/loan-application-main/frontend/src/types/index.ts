import type { components } from '@/types/schemas/api';

export * from './PropTypes';
export type ApiSchema = components['schemas'];
