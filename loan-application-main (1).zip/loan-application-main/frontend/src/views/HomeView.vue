<script setup lang="ts"></script>

<template>
  <main>
    <h1>home page</h1>
  </main>
</template>
