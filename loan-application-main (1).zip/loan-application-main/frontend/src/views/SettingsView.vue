<script setup lang="ts"></script>

<template>
  <main>
    <h1>Settings page</h1>
  </main>
</template>
