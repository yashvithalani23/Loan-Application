<script setup lang="ts"></script>

<template>
  <main>
    <h1>App LOGIN</h1>
  </main>
</template>
